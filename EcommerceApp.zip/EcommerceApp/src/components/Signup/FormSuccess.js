import React from 'react'
import { Link } from "react-router-dom";

export default function FormSuccess(props) {
    return (
        <div className="form-container" style={{ textAlign: "center" }}>
            <h1> Hello {props.name}, Successfully logged.</h1>
            <div>
                <Link to="/" className="form-btn">Logout</Link>
            </div>
        </div>
    )
}
