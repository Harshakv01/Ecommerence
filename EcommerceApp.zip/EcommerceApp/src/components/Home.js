import React from 'react';
import { Link } from "react-router-dom";

export default function Home() {

    return (
        <section>
            <div className="landing-box">
                <div>
                    <h1>Everything you need. Delivered right to your door. We ship you happiness.</h1>
                    <p>We are India's fastest growing Ecommerce Store.</p>
                    <Link to="/products">Shop Now</Link>
                </div>
            </div>
        </section>
    )
}
