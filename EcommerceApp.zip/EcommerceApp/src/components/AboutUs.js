import React from 'react';
import { Link } from "react-router-dom";

export default function AboutUs() {

    return (
        <section>
            <div className="landing-box">
                <div>
                    <h1>Ecommerence  builds for the long term, and that means investing in our planet, our communities, and our people.</h1>
                </div>
            </div>
        </section>
    )
}
