import React from 'react';
import { Link } from "react-router-dom";

export default function ContactUS() {

    return (
        <section>
            <div className="landing-box">
                <div>
                    <h1>For All enquires use the below form to mail us.</h1>
                </div>
                <div>
                <div className="form-group mb-3">
                    <label><strong>Email</strong></label>
                    <input type="email" name="email" className="form-control" />
                </div>
                </div>
            </div>
        </section>
    )
}
